from enum import IntEnum

class Action(IntEnum):
    move_up    = 0
    move_down  = 1
    move_left  = 2
    move_right = 3
