class Action(object):
    def __init__(self, vertex, edge):
        self.vertex = vertex
        self.edge   = edge
